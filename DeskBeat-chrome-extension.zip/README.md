# DeskBeat - Chrome 擴充功能 (Manifest V3)

專為久坐辦公族打造的 60 秒人體工學舒壓節奏遊戲掛件。

## 🌟 核心功能
1. **即點即玩**：點擊 Chrome 工具列圖示，一鍵開啟 60 秒肩頸護眼放鬆。
2. **側邊欄模式 (Side Panel)**：支援在 Chrome 瀏覽器右側邊欄邊看網頁邊放鬆，不佔用額外視窗。
3. **久坐/護眼定時提醒 (番茄鐘)**：可自由設定 30分 / 50分 / 60分 定時彈出 Chrome 桌面推播，提醒起來活動筋骨。
4. **純本機 AI 運算**：鏡頭辨識全在本地端執行，零隱私外洩顧慮。

---

## 🚀 10 秒在本地 Chrome 安裝與體驗教學

1. 打開 Google Chrome 瀏覽器，在網址列輸入：
   ```text
   chrome://extensions
   ```
2. 在頁面右上角，將 **「開發人員模式 (Developer mode)」** 切換為 **開啟**。
3. 點擊左上角的 **「載入未封裝項目 (Load unpacked)」** 按鈕。
4. 在檔案選取視窗中，選擇此資料夾：
   ```text
   /Users/a1-6/Documents/DeskBeat/chrome-extension
   ```
5. 點擊「選取」後，您會在 Chrome 右上角擴充功能清單（拼圖圖示）看到 **DeskBeat**！
6. 點擊釘選圖示將 DeskBeat 固定在工具列，隨時點開即可體驗！
