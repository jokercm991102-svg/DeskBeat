// DeskBeat Chrome Extension Background Service Worker (Manifest V3)

const DEFAULT_INTERVAL_MIN = 50;

chrome.runtime.onInstalled.addListener(() => {
  console.log('DeskBeat Extension Installed!');
  chrome.storage.sync.get(['reminderInterval', 'reminderEnabled'], (res) => {
    const interval = res.reminderInterval || DEFAULT_INTERVAL_MIN;
    const enabled = res.reminderEnabled !== false;

    if (enabled) {
      setupAlarm(interval);
    }
  });

  // 啟用側邊欄支援
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
  }
});

function setupAlarm(minutes) {
  chrome.alarms.clear('deskbeat_reminder', () => {
    if (minutes > 0) {
      chrome.alarms.create('deskbeat_reminder', {
        delayInMinutes: minutes,
        periodInMinutes: minutes
      });
      console.log(`DeskBeat: Alarm set every ${minutes} minutes.`);
    }
  });
}

// 監聽定時器觸發
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'deskbeat_reminder') {
    chrome.notifications.create('deskbeat_break_notification', {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'DeskBeat 工學放鬆時間到囉！🌿',
      message: '👨‍💻 辦公已達預設時長，起來開啟鏡頭做 60 秒肩頸活氧操吧！',
      priority: 2,
      requireInteraction: true
    });
  }
});

// 點擊通知直接開啟遊戲
chrome.notifications.onClicked.addListener((notifId) => {
  if (notifId === 'deskbeat_break_notification') {
    chrome.tabs.create({ url: 'https://43.161.228.192.sslip.io' });
    chrome.notifications.clear(notifId);
  }
});

// 接收來自 popup 的設置變更訊息
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
  if (req.action === 'update_alarm') {
    if (req.enabled) {
      setupAlarm(req.minutes);
    } else {
      chrome.alarms.clear('deskbeat_reminder');
    }
    sendResponse({ status: 'ok' });
  } else if (req.action === 'open_side_panel') {
    if (chrome.sidePanel && chrome.sidePanel.open) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.sidePanel.open({ tabId: tabs[0].id }).catch(() => {
            chrome.tabs.create({ url: 'https://43.161.228.192.sslip.io' });
          });
        }
      });
    } else {
      chrome.tabs.create({ url: 'https://43.161.228.192.sslip.io' });
    }
    sendResponse({ status: 'ok' });
  }
  return true;
});
