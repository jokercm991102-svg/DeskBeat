// DeskBeat Popup Script

const GAME_URL = 'https://43.161.228.192.sslip.io';

document.getElementById('btnLaunchTab').addEventListener('click', () => {
  chrome.tabs.create({ url: GAME_URL });
});

document.getElementById('btnLaunchSidePanel').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'open_side_panel' });
});

// 載入當前提醒設定
const alarmStatus = document.getElementById('alarmStatus');
const reminderButtons = document.querySelectorAll('.reminder-btn');

chrome.storage.sync.get(['reminderInterval', 'reminderEnabled'], (res) => {
  const interval = res.reminderInterval || 50;
  const enabled = res.reminderEnabled !== false;

  updateUI(enabled ? interval : 0);
});

reminderButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    const mins = parseInt(btn.dataset.min, 10);
    const enabled = mins > 0;

    chrome.storage.sync.set({
      reminderInterval: mins,
      reminderEnabled: enabled
    }, () => {
      chrome.runtime.sendMessage({
        action: 'update_alarm',
        minutes: mins,
        enabled: enabled
      });
      updateUI(mins);
    });
  });
});

function updateUI(mins) {
  reminderButtons.forEach(b => {
    if (parseInt(b.dataset.min, 10) === mins) {
      b.classList.add('active');
    } else {
      b.classList.remove('active');
    }
  });

  if (mins > 0) {
    alarmStatus.textContent = `已開啟 (${mins}m)`;
    alarmStatus.style.color = '#88D16B';
  } else {
    alarmStatus.textContent = '已停用';
    alarmStatus.style.color = '#A4B0BE';
  }
}
